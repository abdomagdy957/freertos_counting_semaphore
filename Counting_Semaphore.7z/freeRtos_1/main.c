
#include "StdTypes.h"
#include "DIO_Interface.h"
#include "LCD_Interface.h"

#include "freeRtos.h"
#include "task.h"
#include "semphr.h"

void LCD1(void *pvParameter);
void LCD2(void *pvParameter);

/*define semaphore*/
xSemaphoreHandle LCDSem;

/*parameters for semaphoreCounting func =1 , as a binary semaphore*/
#define uxMaxCount			1
#define uxInitialCount		1

int main(void)
{
	DIO_Init();
	LCD_Init();

	xTaskCreate(LCD1,NULL,300,NULL,1,NULL);
	xTaskCreate(LCD2,NULL,300,NULL,1,NULL);

	/*create countingSemaphore*/
	LCDSem = xSemaphoreCreateCounting(uxMaxCount,uxInitialCount);
	if(LCDSem != NULL)
	{
		/*Semaphore is created successfully*/

	}
	vTaskStartScheduler();
	while(1)
	{

	}
	return 0;
}

void LCD1(void *pvParameter)
{
	u8 state;
	while(1)
	{
		state = xSemaphoreTake(LCDSem,0);
		if(state == pdPASS)
		{
			/*LCD is available*/
			LCD_WriteString("I am Task 1");
			/*give the semaphore after finishing with LCD*/
			xSemaphoreGive(LCDSem);
		}
		else
		{
			/*do nothing*/
		}
		vTaskDelay(100);
	}
}
void LCD2(void *pvParameter)
{
	u8 state;
	while(1)
	{
		state = xSemaphoreTake(LCDSem,0);
		if(state == pdPASS)
		{
			/*LCD is available*/
			LCD_WriteString("I am Task 2");
			/*give the semaphore after finishing with LCD*/
			xSemaphoreGive(LCDSem);
		}
		else
		{
			/*do nothing*/
		}
		vTaskDelay(100);
	}
}

